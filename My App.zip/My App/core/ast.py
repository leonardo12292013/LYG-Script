"""Abstract Syntax Tree classes for LYG Script programming language"""

class LYGNumber:
    def __init__(self, value):
        self.value = value

class LYGVariable:
    def __init__(self, name):
        self.name = name

class LYGBinOp:
    def __init__(self, left, op, right):
        self.left = left
        self.op = op
        self.right = right

class LYGAssign:
    def __init__(self, name, expr):
        self.name = name
        self.expr = expr

class LYGEcho:
    def __init__(self, expr):
        self.expr = expr

class LYGStringLiteral:
    def __init__(self, value):
        self.value = value

class LYGInput:
    def __init__(self, prompt):
        self.prompt = prompt

class LYGFunctionCall:
    def __init__(self, name, args):
        self.name = name
        self.args = args

class LYGArray:
    def __init__(self, elements):
        self.elements = elements

class LYGArrayAccess:
    def __init__(self, array, index):
        self.array = array
        self.index = index

class LYGIf:
    def __init__(self, condition, then_branch, else_branch=None):
        self.condition = condition
        self.then_branch = then_branch
        self.else_branch = else_branch

class LYGWhile:
    def __init__(self, condition, body):
        self.condition = condition
        self.body = body

class LYGFunctionDef:
    def __init__(self, name, params, body):
        self.name = name
        self.params = params
        self.body = body

class LYGReturn:
    def __init__(self, value):
        self.value = value

class LYGProgram:
    def __init__(self, statements):
        self.statements = statements

def print_ast(node, indent=0):
    prefix = '  ' * indent
    if isinstance(node, LYGProgram):
        print(f"{prefix}Program([")
        for stmt in node.statements:
            print_ast(stmt, indent + 1)
        print(f"{prefix}])")

    elif isinstance(node, LYGEcho):
        print(f"{prefix}Echo(")
        print_ast(node.expr, indent + 1)
        print(f"{prefix})")

    elif isinstance(node, LYGAssign):
        print(f"{prefix}Assign(name='{node.name}', expr=")
        print_ast(node.expr, indent + 1)
        print(f"{prefix})")

    elif isinstance(node, LYGBinOp):
        print(f"{prefix}BinOp(")
        print_ast(node.left, indent + 1)
        print(f"{prefix}  '{node.op}'")
        print_ast(node.right, indent + 1)
        print(f"{prefix})")

    elif isinstance(node, LYGNumber):
        print(f"{prefix}Number({node.value})")

    elif isinstance(node, LYGVariable):
        print(f"{prefix}Variable('{node.name}')")

    elif isinstance(node, LYGStringLiteral):
        print(f"{prefix}StringLiteral('{node.value}')")

    elif isinstance(node, LYGInput):
        print(f"{prefix}Input(prompt=")
        print_ast(node.prompt, indent + 1)
        print(f"{prefix})")

    elif isinstance(node, LYGFunctionCall):
        print(f"{prefix}FunctionCall(name='{node.name}', args=[")
        for arg in node.args:
            print_ast(arg, indent + 1)
        print(f"{prefix}])")

    elif isinstance(node, LYGArray):
        print(f"{prefix}Array([")
        for elem in node.elements:
            print_ast(elem, indent + 1)
        print(f"{prefix}])")

    elif isinstance(node, LYGArrayAccess):
        print(f"{prefix}ArrayAccess(")
        print_ast(node.array, indent + 1)
        print_ast(node.index, indent + 1)
        print(f"{prefix})")

    elif isinstance(node, LYGIf):
        print(f"{prefix}If(condition=")
        print_ast(node.condition, indent + 1)
        print(f"{prefix}then_branch=")
        for stmt in node.then_branch:
            print_ast(stmt, indent + 1)
        if node.else_branch:
            print(f"{prefix}else_branch=")
            for stmt in node.else_branch:
                print_ast(stmt, indent + 1)
        print(f"{prefix})")

    elif isinstance(node, LYGWhile):
        print(f"{prefix}While(condition=")
        print_ast(node.condition, indent + 1)
        print(f"{prefix}body=")
        for stmt in node.body:
            print_ast(stmt, indent + 1)
        print(f"{prefix})")

    elif isinstance(node, LYGFunctionDef):
        print(f"{prefix}FunctionDef(name='{node.name}', params={node.params}, body=")
        for stmt in node.body:
            print_ast(stmt, indent + 1)
        print(f"{prefix})")

    elif isinstance(node, LYGReturn):
        print(f"{prefix}Return(")
        print_ast(node.value, indent + 1)
        print(f"{prefix})")

    else:
        print(f"{prefix}Unknown node type: {type(node).__name__}")
