import re
from collections import namedtuple

Token = namedtuple('Token', ['type', 'value'])

KEYWORDS = {'echo', 'LYG', 'print_ast', 'if', 'else', 'while', 'func', 'return'}


TOKEN_SPECIFICATION = [
    ('NUMBER',   r'\d+(\.\d*)?'),
    ('ID',       r'[a-zA-Z][a-zA-Z_0-9]*'),
    ('STRING',   r'"([^"\\]|\\.)*"|\'([^\'\\]|\\.)*\''),
    ('OP',       r'[:]=|==|!=|<=|>=|[+\-*/=<>!&|]'),
    ('LBRACE',   r'\{'),
    ('RBRACE',   r'\}'),
    ('LBRACK',   r'\['),
    ('RBRACK',   r'\]'),
    ('LPAREN',   r'\('),
    ('RPAREN',   r'\)'),
    ('COMMA',    r','),
    ('SEMICOLON',r';'),
    ('SKIP',     r'[ \t]+'),
    ('NEWLINE',  r'\n'),
    ('MISMATCH', r'.')
]

def lex(code):
    tok_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in TOKEN_SPECIFICATION)
    for match in re.finditer(tok_regex, code):
        kind = match.lastgroup
        value = match.group()

        if kind == 'NUMBER':
            value = float(value) if '.' in value else int(value)
            yield Token(kind, value)

        elif kind == 'ID':
            if value in KEYWORDS:
                yield Token(value.upper(), value)
            else:
                yield Token('ID', value)

        elif kind == 'STRING':
            str_val = value[1:-1]
            yield Token(kind, str_val)

        elif kind == 'OP':
            yield Token(kind, value)

        elif kind in ('LBRACE', 'RBRACE', 'LBRACK', 'RBRACK', 'LPAREN', 'RPAREN', 'COMMA', 'SEMICOLON'):
            yield Token(kind, value)

        elif kind in ('NEWLINE', 'SKIP'):
            continue

        elif kind == 'MISMATCH':
            raise SyntaxError(f'Unexpected token: {value!r}')
