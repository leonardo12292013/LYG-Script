from core.ast import (
    LYGAssign, LYGBinOp, LYGNumber, LYGEcho, LYGProgram,
    LYGVariable, LYGStringLiteral, LYGArray, LYGArrayAccess,
    LYGIf, LYGWhile, LYGFunctionDef, LYGFunctionCall, LYGReturn
)

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def advance(self):
        self.pos += 1

    def expect(self, token_type):
        tok = self.peek()
        if tok and tok.type == token_type:
            self.advance()
            return tok
        raise SyntaxError(f'Expected {token_type}, got {tok.type if tok else "EOF"}')

    def parse(self):
        if not (self.peek() and self.peek().type == 'LYG'):
            raise SyntaxError('Script must start with the LYG keyword')
        self.advance()  # consume 'LYG'

        statements = []
        while self.peek() is not None:
            statements.append(self.parse_statement())
        return LYGProgram(statements)

    def parse_statement(self):
        tok = self.peek()
        if tok.type == 'ECHO':
            self.advance()
            expr = self.parse_expression()
            self.expect('SEMICOLON')
            return LYGEcho(expr)

        elif tok.type == 'ID':
            # could be assign or func call
            next_tok = self.tokens[self.pos + 1] if self.pos + 1 < len(self.tokens) else None
            if next_tok and next_tok.type == 'OP' and next_tok.value == ':=':
                var_name = self.expect('ID').value
                self.expect('OP')  # :=
                expr = self.parse_expression()
                self.expect('SEMICOLON')
                return LYGAssign(var_name, expr)
            else:
                expr = self.parse_expression()
                self.expect('SEMICOLON')
                return expr

        elif tok.type == 'IF':
            return self.parse_if()

        elif tok.type == 'WHILE':
            return self.parse_while()

        elif tok.type == 'FUNC':
            return self.parse_function_def()

        elif tok.type == 'RETURN':
            self.advance()
            expr = self.parse_expression()
            self.expect('SEMICOLON')
            return LYGReturn(expr)

        else:
            raise SyntaxError(f'Unexpected token in statement: {tok.type}')

    def parse_if(self):
        self.expect('IF')
        self.expect('LPAREN')
        condition = self.parse_expression()
        self.expect('RPAREN')
        then_branch = self.parse_block()
        else_branch = None
        if self.peek() and self.peek().type == 'ELSE':
            self.advance()
            else_branch = self.parse_block()
        return LYGIf(condition, then_branch, else_branch)

    def parse_while(self):
        self.expect('WHILE')
        self.expect('LPAREN')
        condition = self.parse_expression()
        self.expect('RPAREN')
        body = self.parse_block()
        return LYGWhile(condition, body)

    def parse_function_def(self):
        self.expect('FUNC')
        name = self.expect('ID').value
        self.expect('LPAREN')
        params = []
        if self.peek() and self.peek().type == 'ID':
            params.append(self.expect('ID').value)
            while self.peek() and self.peek().type == 'COMMA':
                self.advance()
                params.append(self.expect('ID').value)
        self.expect('RPAREN')
        body = self.parse_block()
        return LYGFunctionDef(name, params, body)

    def parse_block(self):
        self.expect('LBRACE')
        statements = []
        while self.peek() and self.peek().type != 'RBRACE':
            statements.append(self.parse_statement())
        self.expect('RBRACE')
        return statements

    def parse_expression(self):
        return self.parse_logic_or()

    def parse_logic_or(self):
        expr = self.parse_logic_and()
        while self.peek() and self.peek().type == 'OP' and self.peek().value == '||':
            op = self.expect('OP').value
            right = self.parse_logic_and()
            expr = LYGBinOp(expr, op, right)
        return expr

    def parse_logic_and(self):
        expr = self.parse_equality()
        while self.peek() and self.peek().type == 'OP' and self.peek().value == '&&':
            op = self.expect('OP').value
            right = self.parse_equality()
            expr = LYGBinOp(expr, op, right)
        return expr

    def parse_equality(self):
        expr = self.parse_comparison()
        while self.peek() and self.peek().type == 'OP' and self.peek().value in ('==', '!='):
            op = self.expect('OP').value
            right = self.parse_comparison()
            expr = LYGBinOp(expr, op, right)
        return expr

    def parse_comparison(self):
        expr = self.parse_term()
        while self.peek() and self.peek().type == 'OP' and self.peek().value in ('<', '<=', '>', '>='):
            op = self.expect('OP').value
            right = self.parse_term()
            expr = LYGBinOp(expr, op, right)
        return expr

    def parse_term(self):
        expr = self.parse_factor()
        while self.peek() and self.peek().type == 'OP' and self.peek().value in ('+', '-'):
            op = self.expect('OP').value
            right = self.parse_factor()
            expr = LYGBinOp(expr, op, right)
        return expr

    def parse_factor(self):
        expr = self.parse_unary()
        while self.peek() and self.peek().type == 'OP' and self.peek().value in ('*', '/'):
            op = self.expect('OP').value
            right = self.parse_unary()
            expr = LYGBinOp(expr, op, right)
        return expr

    def parse_unary(self):
        tok = self.peek()
        if tok and tok.type == 'OP' and tok.value in ('-', '!'):
            op = self.expect('OP').value
            right = self.parse_unary()
            return LYGBinOp(None, op, right)
        return self.parse_primary()

    def parse_primary(self):
        tok = self.peek()
        if tok is None:
            raise SyntaxError("Unexpected EOF in expression")

        if tok.type == 'NUMBER':
            self.advance()
            return LYGNumber(tok.value)

        elif tok.type == 'STRING':
            self.advance()
            return LYGStringLiteral(tok.value)

        elif tok.type == 'ID':
            # Может быть переменной или вызовом функции
            id_name = tok.value
            self.advance()
            if self.peek() and self.peek().type == 'LPAREN':
                self.advance()  # '('
                args = []
                if self.peek() and self.peek().type != 'RPAREN':
                    args.append(self.parse_expression())
                    while self.peek() and self.peek().type == 'COMMA':
                        self.advance()
                        args.append(self.parse_expression())
                self.expect('RPAREN')
                return LYGFunctionCall(id_name, args)
            else:
                return LYGVariable(id_name)

        elif tok.type == 'LPAREN':
            self.advance()
            expr = self.parse_expression()
            self.expect('RPAREN')
            return expr

        elif tok.type == 'LBRACK':
            self.advance()
            elements = []
            if self.peek() and self.peek().type != 'RBRACK':
                elements.append(self.parse_expression())
                while self.peek() and self.peek().type == 'COMMA':
                    self.advance()
                    elements.append(self.parse_expression())
            self.expect('RBRACK')
            return LYGArray(elements)

        else:
            raise SyntaxError(f"Unexpected token {tok.type} in expression")
