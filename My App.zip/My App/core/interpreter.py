"""Interpreter for LYG Script Programming Language (with toNumber, toString, input, and if support)"""

from core.ast import (
    LYGAssign,
    LYGBinOp,
    LYGNumber,
    LYGEcho,
    LYGProgram,
    LYGVariable,
    LYGStringLiteral,
    LYGInput,
    LYGFunctionCall,
    LYGIf
)

class Interpreter:

    def __init__(self):
        self.env = {}

    def eval(self, node):
        if isinstance(node, LYGProgram):
            return self._eval_program(node)
        elif isinstance(node, LYGAssign):
            return self._eval_assign(node)
        elif isinstance(node, LYGEcho):
            return self._eval_echo(node)
        elif isinstance(node, LYGBinOp):
            return self._eval_binop(node)
        elif isinstance(node, LYGNumber):
            return node.value
        elif isinstance(node, LYGVariable):
            return self.env.get(node.name, None)
        elif isinstance(node, LYGStringLiteral):
            return node.value
        elif isinstance(node, LYGInput):
            return self._eval_input(node)
        elif isinstance(node, LYGFunctionCall):
            return self._eval_function_call(node)
        elif isinstance(node, LYGIf):
            return self._eval_if(node)  # Добавляем поддержку LYGIf
        else:
            raise TypeError(f'Unknown node type: {type(node).__name__}')

    def _eval_program(self, node):
        for stmt in node.statements:
            self.eval(stmt)

    def _eval_assign(self, node):
        value = self.eval(node.expr)
        self.env[node.name] = value
        return value

    def _eval_echo(self, node):
        value = self.eval(node.expr)
        print(value)

    def _eval_binop(self, node):
        left = self.eval(node.left)
        right = self.eval(node.right)
        op = node.op

        if op == '+':
            return left + right
        elif op == '-':
            return left - right
        elif op == '*':
            return left * right
        elif op == '/':
            return left / right
        elif op == '==':
            return left == right
        elif op == '!=':
            return left != right
        elif op == '<':
            return left < right
        elif op == '>':
            return left > right
        elif op == '<=':
            return left <= right
        elif op == '>=':
            return left >= right
        else:
            raise ValueError(f'Unknown binary operator: {op}')

    def _eval_input(self, node):
        prompt = self.eval(node.prompt) if node.prompt else ''
        return input(prompt)

    def _eval_function_call(self, node):
        func_name = node.name
        args = [self.eval(arg) for arg in node.args]

        if func_name == 'toNumber':
            try:
                if '.' in str(args[0]):
                    return float(args[0])
                else:
                    return int(args[0])
            except Exception:
                raise ValueError(f"Cannot convert to number: {args[0]}")

        elif func_name == 'toString':
            return str(args[0])

        elif func_name == "input":
            if len(args) != 1:
                raise TypeError("input() takes exactly one argument")
            return input(str(args[0]))

        else:
            raise NameError(f"Unknown function: {func_name}")

    def _eval_if(self, node):
        condition_value = self.eval(node.condition)
        if condition_value:
            for stmt in node.then_branch:
                self.eval(stmt)
        elif node.else_branch:
            for stmt in node.else_branch:
                self.eval(stmt)
