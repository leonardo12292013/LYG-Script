import sys
from core.lexer import lex
from core.parser import Parser
from core.interpreter import Interpreter  # Импорт интерпретатора

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Пожалуйста, укажите имя файла с расширением .ly")
        sys.exit(1)

    filename = sys.argv[1]

    if not filename.endswith('.ly'):
        print("Ошибка: файл должен иметь расширение .ly")
        sys.exit(1)

    # Чтение исходного кода из указанного файла
    with open(filename, 'r', encoding='utf-8') as f:
        code = f.read()

    # Лексический анализ
    tokens = list(lex(code))

    # Синтаксический анализ
    parser = Parser(tokens)
    ast = parser.parse()

    # Интерпретация AST
    print("\n✅ Output:")
    interpreter = Interpreter()
    interpreter.eval(ast)

    input("\n\nНажмите Enter, чтобы закрыть...")